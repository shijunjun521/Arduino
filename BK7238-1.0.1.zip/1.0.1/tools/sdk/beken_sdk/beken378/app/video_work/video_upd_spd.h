#ifndef __VIDEO_UDP_SDP_H__
#define __VIDEO_UDP_SDP_H__

#include "include.h"

int vudp_sdp_start(void);
int vudp_sdp_stop(void);


#endif //
