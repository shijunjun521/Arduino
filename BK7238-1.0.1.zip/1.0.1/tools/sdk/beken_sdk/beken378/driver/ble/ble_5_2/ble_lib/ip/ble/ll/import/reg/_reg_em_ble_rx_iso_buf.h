#ifndef __REG_EM_BLE_RX_ISO_BUF_H_
#define __REG_EM_BLE_RX_ISO_BUF_H_

extern uint8_t ex_mem[];

#define REG_EM_BLE_RX_ISO_BUF_SIZE 260

#define REG_EM_BLE_RX_ISO_BUF_BASE_ADDR ((uintptr_t)ex_mem)


#endif // __REG_EM_BLE_RX_ISO_BUF_H_

