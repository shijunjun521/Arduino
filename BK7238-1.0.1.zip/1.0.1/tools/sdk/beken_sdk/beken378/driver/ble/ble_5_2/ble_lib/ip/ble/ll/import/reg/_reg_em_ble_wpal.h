#ifndef __REG_EM_BLE_WPAL_H_
#define __REG_EM_BLE_WPAL_H_

extern uint8_t ex_mem[];

#define REG_EM_BLE_WPAL_SIZE 12

#define REG_EM_BLE_WPAL_BASE_ADDR ((uintptr_t)ex_mem)


#endif // __REG_EM_BLE_WPAL_H_

