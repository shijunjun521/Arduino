#ifndef __REG_EM_BLE_RX_DESC_H_
#define __REG_EM_BLE_RX_DESC_H_

extern uint8_t ex_mem[];

#define REG_EM_BLE_RX_DESC_SIZE 28

#define REG_EM_BLE_RX_DESC_BASE_ADDR ((uintptr_t)ex_mem)


#endif // __REG_EM_BLE_RX_DESC_H_

