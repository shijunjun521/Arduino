#ifndef __REG_IPCORE_H_
#define __REG_IPCORE_H_

#define REG_IPCORE_SIZE 408

#define REG_IPCORE_BASE_ADDR 0x00900000


#endif // __REG_IPCORE_H_

