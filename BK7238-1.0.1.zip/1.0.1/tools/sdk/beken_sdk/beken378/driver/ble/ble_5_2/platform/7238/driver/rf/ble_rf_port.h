#ifndef __BLE_RF_PORT__
#define __BLE_RF_PORT__

void ble_release_rf_by_isr(void);
void ble_request_rf_by_isr(void);

#endif
