#ifndef __REG_EM_ET_H_
#define __REG_EM_ET_H_

extern uint8_t ex_mem[];

#define REG_EM_ET_SIZE 16

#define REG_EM_ET_BASE_ADDR ((uintptr_t)ex_mem)


#endif // __REG_EM_ET_H_

