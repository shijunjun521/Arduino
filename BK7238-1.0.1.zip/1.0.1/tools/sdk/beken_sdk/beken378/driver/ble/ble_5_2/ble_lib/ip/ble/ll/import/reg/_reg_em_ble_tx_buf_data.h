#ifndef __REG_EM_BLE_TX_BUF_DATA_H_
#define __REG_EM_BLE_TX_BUF_DATA_H_

extern uint8_t ex_mem[];

#define REG_EM_BLE_TX_BUF_DATA_SIZE 260

#define REG_EM_BLE_TX_BUF_DATA_BASE_ADDR ((uintptr_t)ex_mem)


#endif // __REG_EM_BLE_TX_BUF_DATA_H_

