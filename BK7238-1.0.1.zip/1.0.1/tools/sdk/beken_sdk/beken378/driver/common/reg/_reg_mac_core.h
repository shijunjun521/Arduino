#ifndef __REG_MAC_CORE_H_
#define __REG_MAC_CORE_H_

#define REG_MAC_CORE_SIZE         1376
#define REG_MAC_CORE_BASE_ADDR    0xC0000000

#endif // __REG_MAC_CORE_H_
// eof

