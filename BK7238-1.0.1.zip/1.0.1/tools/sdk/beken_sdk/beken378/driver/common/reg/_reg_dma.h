#ifndef __REG_DMA_H_
#define __REG_DMA_H_

#define REG_DMA_SIZE 196

#define REG_DMA_BASE_ADDR 0x10A00000


#endif // __REG_DMA_H_

