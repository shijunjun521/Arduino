#ifndef __REG_MAC_PTA_H_
#define __REG_MAC_PTA_H_

#define REG_MAC_PTA_SIZE 36

#define REG_MAC_PTA_BASE_ADDR 0xC0010000


#endif // __REG_MAC_PTA_H_

