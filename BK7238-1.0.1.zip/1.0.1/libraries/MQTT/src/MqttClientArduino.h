
#ifndef _MQTTCLIENTARDUINO_H_
#define _MQTTCLIENTARDUINO_H_

#define PAHOMQTT_PIPE_MODE 1

#include <stdlib.h>
#include <stdint.h>
#include <string>
#include "include.h"
#include "str_pub.h"
#include "PahoMqtt.h"



using MqttCallback = void (*)(void*);
using MqttSubscribeCallback = void (*)(const char * topic,const char * payload);

class MqttClient:public MQTT_CLIENT_T
{
public:

    struct Config 
	{
        std::string brokerAddress;
        std::string clientId;
        std::string username;
        std::string password;
        int keepAliveInterval = 60;
        int connectionTimeout = 10;
        unsigned cleanSession = 1;
        int qos = 1;
        //bool autoReconnect = true;
        //int maxReconnectAttempts = 5;
        //int reconnectDelay = 2;
    };

    MqttClient(const Config& config);
    
    ~MqttClient();
    
    bool Connect(void);
    
    bool Disconnect();
    
    bool Publish(const std::string& topic, const std::string& payload, 
                 QoS qos = QOS1);
    
    bool Subscribe(const std::string& topic, QoS qos = QOS1);
    
    bool IsConnected() const;

	void SetConnectCallback(const MqttCallback& callback)
	{
		ConnectCallback = callback;
	}

	void SetOnlineCallback(const MqttCallback& callback)
	{
		OnlineCallback = callback;
	}

	void SetOfflineCallback(const MqttCallback& callback)
	{
		OfflineCallback = callback;
	}

	void SetSubscribeCallback(const MqttSubscribeCallback& callback)
	{
		SubscribeCallback = callback;
	}
private:

	static void mqtt_connect_callback(MQTT_CLIENT_T *c)
	{
		bk_printf("mqtt_connect_callback\r\n");
		static_cast<MqttClient *>(c)->ConnectCallback(NULL); 
		return;
	}

	static void mqtt_online_callback(MQTT_CLIENT_T *c)
	{
		bk_printf("mqtt_online_callback\r\n");
		static_cast<MqttClient *>(c)->OnlineCallback(NULL);
		return;
	}

	static void mqtt_offline_callback(MQTT_CLIENT_T *c)
	{
		bk_printf("mqtt_offline_callback\r\n");
		static_cast<MqttClient *>(c)->OfflineCallback(NULL);
		return;
	}

	static void mqtt_sub_callback(MQTT_CLIENT_T *c, MessageData *msg_data)
	{
		//bk_printf("Message arrived on topic %.*s: %.*s\r\n", 
		//		msg_data->topicName->lenstring.len,
		//		msg_data->topicName->lenstring.data,
		//		msg_data->message->payloadlen, 
		//		msg_data->message->payload);

		if (msg_data->message->payloadlen > 0) 
		{
			((char*)msg_data->message->payload)[msg_data->message->payloadlen] = '\0';
		}
		const char *topic = msg_data->topicName->lenstring.data;
		const char *payload = (const char*)msg_data->message->payload;
		
        static_cast<MqttClient *>(c)->SubscribeCallback(topic,payload);
		return;
	}
    
    MqttCallback ConnectCallback;
	MqttCallback OnlineCallback;
	MqttCallback OfflineCallback;
	MqttSubscribeCallback SubscribeCallback;
};

#endif//_MQTTCLIENTARDUINO_H_
