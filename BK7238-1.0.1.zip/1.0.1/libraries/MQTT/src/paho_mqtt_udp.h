#ifndef __PAHO_MQTT_UDP_H__
#define __PAHO_MQTT_UDP_H__

#define  debug_printf           os_printf("[MQTT] ");os_printf

#endif // __PAHO_MQTT_UDP_H__
// eof
