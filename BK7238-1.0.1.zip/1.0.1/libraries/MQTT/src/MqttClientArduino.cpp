#include "MqttClientArduino.h"

MqttClient::MqttClient(const Config& config)
{
    //MQTTPacket_connectData condata = MQTTPacket_connectData_initializer;

    os_memset((uint8_t*)&this->uri, 0, sizeof(MQTT_CLIENT_T));

    bk_printf("mqtt_start\r\n");
    /* config MQTT context param */
    uri = config.brokerAddress.c_str();

    /* config connect param */
    os_memcpy(&this->condata, &condata, sizeof(condata));
    condata.clientID.cstring = const_cast<char*>(config.clientId.c_str());
    condata.keepAliveInterval = 60;
    condata.cleansession = 1;
    condata.username.cstring = const_cast<char*>(config.username.c_str());
    condata.password.cstring = const_cast<char*>(config.password.c_str());

    /* config MQTT will param. */
    condata.willFlag = 1;
    condata.will.qos = QOS1;
    condata.will.retained = 0;
    condata.will.topicName.cstring = "/lh/test";
    condata.will.message.cstring = "Hello Beken";

    /* set event callback function */
    online_callback = mqtt_online_callback;
    connect_callback = mqtt_connect_callback;
    offline_callback = mqtt_offline_callback;


    MqttCallback ConnectCallback = nullptr;
	MqttCallback OnlineCallback = nullptr;
	MqttCallback OfflineCallback = nullptr;
	MqttSubscribeCallback SubscribeCallback = nullptr;

    /* malloc buffer. */
    buf_size = readbuf_size = 1024;
    buf = static_cast<unsigned char*>(os_malloc(buf_size));
    readbuf = static_cast<unsigned char*>(os_malloc(readbuf_size));
    if (!(buf && readbuf))
    {
        bk_printf("no memory for MQTT mqtt_client buffer!\n");
        goto _exit;
    }

    return;

_exit:
    if (buf)
    {
        os_free(buf);
        buf = NULL;
    }

    if (readbuf)
    {
        os_free(readbuf);
        readbuf = NULL;
    }

    return;
}


MqttClient::~MqttClient() 
{
    Disconnect();
    os_free(buf);
    os_free(readbuf);
}


bool MqttClient::Connect(void) 
{
    /* run mqtt client */
    bk_printf("mqtt client start\r\n");
    paho_mqtt_start((MQTT_CLIENT_T *)this);

	return true;
}

bool MqttClient::Disconnect(void) 
{
	bk_printf("MQTT to disconnnect\r\n");
	//Disconnect();
    return true;
}

bool MqttClient::Publish(const std::string& topic, const std::string& payload, 
                        QoS qos) 
{

	if (!IsConnected()) 
	{
		bk_printf("MQTT is not connected, and cannot send message\r\n");
		return false;
	}

	MQTTMessage message;
    const char *msg_str = payload.c_str();
    const char *publish_topic = topic.c_str();

    message.qos = QOS1;
    message.retained = 0;
    message.payload = (void *)msg_str;
    message.payloadlen = os_strlen((const char *)message.payload);
	
	mqtt_publish_with_topic((MQTT_CLIENT_T *)this, publish_topic, &message);
	return true;
}

extern "C" char *os_strdup1(const char *s,size_t len)
{
    char *res;

    if (s == NULL)
        return NULL;

    res = (char*)os_malloc(len + 1);
    if (res)
        os_memcpy(res, s, len + 1);

    return res;
}

bool MqttClient::Subscribe(const std::string& topic, QoS qos) 
{
    /* set subscribe table and event callback */

    //size_t len = topic.size() + 1;
    //char* dest = (char*)os_malloc(len);
    //
    //if (dest != NULL) 
    //{
    //    os_memcpy(dest, &topic.c_str(), len); 
    //}
    //messageHandlers[0].topicFilter = dest;
    //os_memcpy(messageHandlers[0].topicFilter,topic.c_str(),topic.size());
    messageHandlers[0].topicFilter = os_strdup1(topic.c_str(),topic.size());
    messageHandlers[0].callback = mqtt_sub_callback;
    messageHandlers[0].qos = qos;

    /* set default subscribe event callback */
    defaultMessageHandler = mqtt_sub_callback;

    return true;
}


bool MqttClient::IsConnected() const 
{
    return is_connected;
}
