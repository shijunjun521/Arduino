#include "Arduino.h"
#include "include.h"

extern "C" void extended_app_waiting_for_launch(void);

extern "C" void user_main(void)
{
	extended_app_waiting_for_launch();
	log_enable();
	setup();
	while(1)
	{
		rtos_delay_milliseconds(2);
		loop();
	}
}
