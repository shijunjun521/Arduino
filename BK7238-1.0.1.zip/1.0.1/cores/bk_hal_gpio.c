
#include "include.h"
#include "bk_hal_gpio.h"
#include "BkDriverGpio.h"
#include "gpio_pub.h"


#define GPIO_IS_VALID_GPIO(gpio_num)   (gpio_num == GPIO0  || gpio_num == GPIO1  || gpio_num == GPIO6  || gpio_num == GPIO7 || gpio_num == GPIO8   ||  \
                                        gpio_num == GPIO9  || gpio_num == GPIO10 || gpio_num == GPIO11 || gpio_num == GPIO14 || gpio_num == GPIO15 ||  \
                                        gpio_num == GPIO16 || gpio_num == GPIO17 || gpio_num == GPIO20 || gpio_num == GPIO21 || gpio_num == GPIO22 ||  \
                                        gpio_num == GPIO23 || gpio_num == GPIO24 || gpio_num == GPIO26 || gpio_num == GPIO28)


void pinMode(uint8_t pin, uint8_t mode)
{
    if(!GPIO_IS_VALID_GPIO(pin))
    {
        bk_printf("GPIO_IS_UNVALID_GPIO\r\n");
        return;
    }

	if (mode == INPUT) { 
        BkGpioInitialize(pin,INPUT_NORMAL);
	} else if (mode == INPUT_PULLUP) {
        BkGpioInitialize(pin,INPUT_PULL_UP);
	} else if(mode == OUTPUT) {
        BkGpioInitialize(pin,OUTPUT_NORMAL);
	}
    else{
        bk_printf("GPIO mode err\r\n");
    }

    return;
}

void digitalWrite(uint8_t pin, uint8_t val)
{
    if(!GPIO_IS_VALID_GPIO(pin))
    {
        bk_printf("GPIO_IS_UNVALID_GPIO\r\n");
        return;
    }

    bk_gpio_output(pin, val);

    return;
}

int digitalRead(uint8_t pin)
{
    if(!GPIO_IS_VALID_GPIO(pin))
    {
        bk_printf("GPIO_IS_UNVALID_GPIO\r\n");
        return -1;
    }

    return bk_gpio_input(pin);
}
