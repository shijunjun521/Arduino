#include "Arduino.h"
#include "ntp.h"
#include "rtc.h"
#include "rtc_time.h"
#include "time.h"

#if 0
static void setTimeZone(long offset, int daylight)
{
    char cst[17] = {0};
    char cdt[17] = "DST";
    char tz[33] = {0};

    if(offset % 3600){
        sprintf(cst, "UTC%ld:%02u:%02u", offset / 3600, abs((offset % 3600) / 60), abs(offset % 60));
    } else {
        sprintf(cst, "UTC%ld", offset / 3600);
    }
    if(daylight != 3600){
        long tz_dst = offset - daylight;
        if(tz_dst % 3600){
            sprintf(cdt, "DST%ld:%02u:%02u", tz_dst / 3600, abs((tz_dst % 3600) / 60), abs(tz_dst % 60));
        } else {
            sprintf(cdt, "DST%ld", tz_dst / 3600);
        }
    }
    sprintf(tz, "%s%s", cst, cdt);
    setenv("TZ", tz, 1);
    tzset();
}
#endif

void configTime(long gmtOffset_sec, int daylightOffset_sec, const char* server1, const char* server2, const char* server3)
{
    ntp_set_servername(0, (char*)server1);
    ntp_set_servername(1, (char*)server2);
    ntp_set_servername(2, (char*)server3);
    rt_rtc_ntp_sync_init();
}

#if 0
/*
 * configTzTime
 * sntp setup using TZ environment variable
 * */
void configTzTime(const char* tz, const char* server1, const char* server2, const char* server3)
{
    if(sntp_enabled()){
        sntp_stop();
    }
    sntp_setoperatingmode(SNTP_OPMODE_POLL);
    sntp_setservername(0, (char*)server1);
    sntp_setservername(1, (char*)server2);
    sntp_setservername(2, (char*)server3);
    sntp_init();
    setenv("TZ", tz, 1);
    tzset();
}
#endif

bool getLocalTime(struct tm_at * info, uint32_t ms)
{
    uint32_t start = millis();
    time_t_at now1;

    while((millis()-start) <= ms) {
        //time(&now);
        time_at(&now1);

        //localtime_r(&now, info);
        localtime_r_at(&now1, info);
        if(info->tm_year > (2016 - 1900)){
            return true;
        }
        delay(10);
    }
    return false;
}



bool getLocalTime1(struct tm * info, uint32_t ms)
{
    uint32_t start = millis();
    time_t now;

    while((millis()-start) <= ms) {
        time(&now);

        localtime_r(&now, info);

        if(info->tm_year > (2016 - 1900)){
            return true;
        }
        delay(10);
    }
    return false;
}