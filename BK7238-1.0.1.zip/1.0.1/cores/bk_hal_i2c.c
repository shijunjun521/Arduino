#include "bk_hal.h"
#include "i2c_pub.h"
#include "drv_model_pub.h"
#include "bk_hal_i2c.h"

static DD_HANDLE i2c_dev = 0;

static uint8_t salve_id = 0;


void i2c_init()
{
    UINT32 status;
    uint32_t flag = (I2C_CLK_DIVID(I2C_DEFAULT_BAUD) << 6);

    i2c_dev = ddev_open(I2C2_DEV_NAME, &status, flag);

    if(0 != status)
    {
        bk_printf("open i2c failed:%d\r\n", status);
        return ;
    }
    else
    {
        bk_printf("open i2c success\r\n");
    }
}

void i2c_set_slave_id(uint8_t addr)
{
    salve_id = addr;
}


uint8_t i2c_write(uint8_t data)
{
    I2C_OP_ST i2c_op;
    i2c_op.op_addr  = 0;
    i2c_op.addr_width = ADDR_WIDTH_8;
    i2c_op.salve_id = salve_id;

    ddev_write(i2c_dev, (char*)&data, 1, (u32)&i2c_op);

    return 1;
}

void i2c_read(uint8_t *data,uint32_t len)
{
    I2C_OP_ST i2c_op;
    i2c_op.op_addr  = 0;
    i2c_op.addr_width = ADDR_WIDTH_8;
    i2c_op.salve_id = salve_id;

    ddev_read(i2c_dev, (char*)data, len, (u32)&i2c_op);
}

void i2c_stop()
{
    ddev_close(i2c_dev);
}
