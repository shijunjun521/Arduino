#ifdef __cplusplus
extern "C" {
#endif

void i2c_init();
void i2c_set_slave_id(uint8_t addr);
uint8_t i2c_write(uint8_t data);
void i2c_read(uint8_t *data,uint32_t len);
void i2c_stop();

#ifdef __cplusplus
}
#endif
