#include "include.h"
#include "bk_hal_pwm.h"
#include "BkDriverPwm.h"
#include "drv_model_pub.h"
#include "pwm_pub.h"

#define PWM_NUMBER 6

#define PWM_STATUS_IDLE 0
#define PWM_STATUS_RUNNING 1
#define PWM_1K_HZ (26*1000)

const uint8_t pwm_pin_map[PWM_NUMBER]={6,7,8,9,24,26};
static uint8_t pwm_stat[PWM_NUMBER] ={0,0,0,0,0,0};
static uint8_t resolution_bit = 8;//all pwm share one resolution

void analogWriteResolution(uint8_t bits)
{
	if(bits == resolution_bit)
		return;
	
	if(bits < 8)
		resolution_bit = 8;
	else if(bits > 12)
		resolution_bit = 12;
	else
		resolution_bit = bits;
}

void analogWrite(uint8_t pin, int value)
{
	uint8_t pwm_index = 0;
	int frequency = PWM_1K_HZ;
	int duty;
	OSStatus ret;
	
	if(value >= (1 << resolution_bit))
		return;
	
	/*ratio trasnlation*/
	duty = value * frequency / ((1 << resolution_bit) -1);
	
	do
	{
		if(pwm_pin_map[pwm_index] == pin)
			break;
		pwm_index++;
	}while(pwm_index < PWM_NUMBER);

	if(pwm_index >= PWM_NUMBER)
		return;
	if(pwm_stat[pwm_index] == PWM_STATUS_IDLE)
	{
		ret = bk_pwm_initialize(pwm_index,frequency,duty);
		if(ret != PWM_SUCCESS)
			return;
		
		ret = bk_pwm_start(pwm_index);
		if(ret != PWM_SUCCESS)
			return;

		pwm_stat[pwm_index] = PWM_STATUS_RUNNING;
	}
	else
	{
		bk_pwm_update_param(pwm_index, frequency, duty);
	}
	
}
