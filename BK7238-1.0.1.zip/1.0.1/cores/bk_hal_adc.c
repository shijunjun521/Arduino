#include "string.h"
#include "stdlib.h"
#include "mem_pub.h"
#include "uart_pub.h"
#include "gpio_pub.h"
#include "error.h"
#include "saradc_pub.h"
#include "bk_hal_adc.h"

static saradc_desc_t test_adc_demo_adc1;
static DD_HANDLE test_adc_demo_handle = -1;

void analogReadResolution(int bits)
{
	return;
}

void test_adc_demo_isr_cb(void)
{
    UINT32 sum = 0;
    UINT16 *pData = test_adc_demo_adc1.pData;

    if(test_adc_demo_adc1.data_buff_size <= test_adc_demo_adc1.current_sample_data_cnt)
    {
        ddev_close(test_adc_demo_handle);
        saradc_ensure_close();

        for(int i = 0;i < test_adc_demo_adc1.data_buff_size;i++)
        {
           sum += pData[i];
        }

        pData[0] = sum/test_adc_demo_adc1.data_buff_size;

        //int mv = 1000*saradc_calculate(pData[0]);
        //bk_printf("mv:%d\r\n",mv);
    }
}

VOID test_adc_demo_init(int channel)
{
    uint32_t ret;
    UINT32 status;
    GLOBAL_INT_DECLARATION();

    os_memset(&test_adc_demo_adc1, 0x00, sizeof(saradc_desc_t));
    saradc_config_param_init(&test_adc_demo_adc1);

    test_adc_demo_adc1.channel = channel;
    test_adc_demo_adc1.data_buff_size = 20;
    test_adc_demo_adc1.mode = 3;
    test_adc_demo_adc1.current_read_data_cnt = 0;
    test_adc_demo_adc1.current_sample_data_cnt = 0;
    test_adc_demo_adc1.has_data = 0;
    test_adc_demo_adc1.p_Int_Handler = test_adc_demo_isr_cb;
    test_adc_demo_adc1.pData = os_malloc(sizeof(UINT16) * test_adc_demo_adc1.data_buff_size);
    if(!test_adc_demo_adc1.pData)
    {
        os_printf("malloc failed\n");
        return;
    }

    ret = 0;
    do {
        GLOBAL_INT_DISABLE();
        if(saradc_check_busy() == 0) {
            test_adc_demo_handle = ddev_open(SARADC_DEV_NAME, &status, (UINT32)&test_adc_demo_adc1);
            if(DD_HANDLE_UNVALID != test_adc_demo_handle)
            {
                GLOBAL_INT_RESTORE();
                break;
            }
        }
        GLOBAL_INT_RESTORE();
        rtos_delay_milliseconds(5);
        ret++;
    } while(ret<5);

    if(ret == 5) {
        os_free(test_adc_demo_adc1.pData);
        os_printf("adc_open failed\n");
        return;
    }
}

int analogRead(uint8_t pin)
{     
    int val ;
    if(test_adc_demo_adc1.pData) 
    {
        os_free(test_adc_demo_adc1.pData);
        test_adc_demo_adc1.pData = NULL;
    }
    test_adc_demo_init(pin);
    while(test_adc_demo_adc1.data_buff_size > test_adc_demo_adc1.current_sample_data_cnt)
    {
        rtos_delay_milliseconds(200);
    }
    val = test_adc_demo_adc1.pData[0];
    ddev_close(test_adc_demo_handle);
    return val;
}
