#ifndef _BK_HAL_ADC_H_
#define _BK_HAL_ADC_H_

#ifdef __cplusplus
extern "C" {
#endif

int analogRead(uint8_t pin);
void analogReadResolution(int resolution);
#ifdef __cplusplus
}
#endif
#endif
