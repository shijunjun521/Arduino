#include "Arduino.h"
#include "include.h"


unsigned long  micros()
{
    return (unsigned long) (rtos_get_time_us());
}

unsigned long  millis()
{
    return (unsigned long) (rtos_get_time_us() / 1000ULL);
}

void  delayMicroseconds(uint32_t us)
{
    uint64_t m = (uint64_t)rtos_get_time_us();
    if(us){
        uint64_t e = (m + us);
        if(m > e){ //overflow
            while((uint64_t)rtos_get_time_us() > e){
               __asm ( "NOP" );
            }
        }
        while((uint64_t)rtos_get_time_us() < e){
           __asm ( "NOP" );
        }
    }
}

void delay(uint32_t ms)
{
   	rtos_delay_milliseconds(ms);
}