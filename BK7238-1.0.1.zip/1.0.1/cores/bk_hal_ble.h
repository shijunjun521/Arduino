#ifdef __cplusplus
extern "C" {
#endif

#include "ble_api_5_x.h"

#define MAX_CHAR_VAULE_SIZE    512

int bk_add_characteristic(uint8_t service_hander,uint8_t *uuid,uint8_t uuid_len, uint32_t properties);
void bk_add_service(uint8_t service_hander,uint8_t *uuid,uint8_t uuid_len);
void bk_start_service(uint8_t service_hander);
void bk_dev_init();
void bk_server_disconnect(void);

extern int hexstr2bin(const char *hex, u8 *buf, size_t len);

typedef enum {
    BLE_PROPERTY_READ      		= 1<<0,
    BLE_PROPERTY_WRITE     		= 1<<1,
    BLE_PROPERTY_NOTIFY    		= 1<<2,
    BLE_PROPERTY_BROADCAST 		= 1<<3,
    BLE_PROPERTY_INDICATE  		= 1<<4,
    BLE_PROPERTY_WRITE_NO_RSP  	= 1<<5,
}char_prop_bf_t;

#ifdef __cplusplus
}
#endif
