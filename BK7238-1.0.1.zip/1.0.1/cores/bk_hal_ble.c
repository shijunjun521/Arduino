
#include "include.h"
#include "rtos_pub.h"
#include "bk_hal_ble.h"
#include <string.h>
#include <stdlib.h>

#define ATT_DECL_PRIMARY_SERVICE     "\x00\x28\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0"
#define ATT_DECL_CHARACTERISTIC      "\x03\x28\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0"
#define ATT_DESC_CLIENT_USER_CFG     "\x01\x29\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0"
#define ATT_DESC_CLIENT_CHAR_CFG     "\x02\x29\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0"

#define MAX_SERVICE_NUM                 4
#define MAX_CHARACTERISTIC_NUM          12

typedef struct {
    unsigned char inited;
    unsigned char uuidLen;
    unsigned char server_id;
    unsigned char att_idx;
    char *svc_uuid;
    bk_attm_desc_t *service_db;
} BtServer;

typedef struct {
	uint8_t srv_num;
    BtServer srv[MAX_SERVICE_NUM];
} ServerList_t;

ServerList_t srv_db_list;

void bk_add_service(uint8_t service_hander,uint8_t *uuid,uint8_t uuid_len)
{
    if(srv_db_list.srv[service_hander].inited)
    {
        bk_printf("service[%d] had init\r\n",service_hander);
        return;
    }

    srv_db_list.srv_num += 1;
    srv_db_list.srv[service_hander].server_id = service_hander;
    srv_db_list.srv[service_hander].uuidLen = uuid_len;

    srv_db_list.srv[service_hander].svc_uuid = malloc(uuid_len);
    memcpy(srv_db_list.srv[service_hander].svc_uuid,uuid,uuid_len);

    srv_db_list.srv[service_hander].att_idx = 0;
    srv_db_list.srv[service_hander].service_db = malloc(MAX_CHARACTERISTIC_NUM *sizeof(bk_attm_desc_t));
    srv_db_list.srv[service_hander].inited = 1;
}

int bk_add_characteristic(uint8_t service_hander,uint8_t *uuid,uint8_t uuid_len, uint32_t properties)
{
    bk_attm_desc_t *service_db;
    uint32_t bk_prop = 0;
    uint8_t cccd_idx = 0;
    uint8_t att_idx = 0;

    if(!srv_db_list.srv[service_hander].inited)
    {
        bk_printf("service[%d] no init\r\n",service_hander);
        return -1;
    }
    
    att_idx = srv_db_list.srv[service_hander].att_idx;
    service_db = srv_db_list.srv[service_hander].service_db;
    if(!att_idx)
    {
        memcpy(service_db[att_idx].uuid, (uint8_t *)ATT_DECL_PRIMARY_SERVICE, 2);
        service_db[att_idx].info = PROP(RD);
        service_db[att_idx].ext_info = 0;
        att_idx++;
    }

    memcpy(service_db[att_idx].uuid, (uint8_t *)ATT_DECL_CHARACTERISTIC, 2);
    service_db[att_idx].info = PROP(RD);
    service_db[att_idx].ext_info = 0;
    att_idx++;
     
    if(properties & BLE_PROPERTY_READ)
    {
        bk_prop |= PROP(RD);
    }

    if(properties & BLE_PROPERTY_WRITE)
    {
        bk_prop |= PROP(WR);
    }

    if(properties & BLE_PROPERTY_NOTIFY)
    {
        cccd_idx = att_idx;
        bk_prop |= PROP(N);  
    }

    if(properties & BLE_PROPERTY_WRITE_NO_RSP)
    {
        bk_prop |= PROP(WC);
    }

    if(properties & BLE_PROPERTY_INDICATE)
    {
        cccd_idx = att_idx;
        bk_prop |= PROP(I);
    }

    if(uuid_len ==16)
    {
       bk_prop |= ATT_UUID(128);
    }

    /*add Characteristic*/
    memcpy(service_db[att_idx].uuid, uuid, uuid_len);
    service_db[att_idx].info = bk_prop;
    service_db[att_idx].ext_info = MAX_CHAR_VAULE_SIZE|OPT(NO_OFFSET);
    att_idx++;

    /*add descriptor*/
    if(cccd_idx) 
    {
        memcpy(service_db[att_idx].uuid, (uint8_t *)ATT_DESC_CLIENT_CHAR_CFG, 2);
        service_db[att_idx].info = PROP(RD)|PROP(WR);
        service_db[att_idx].ext_info = OPT(NO_OFFSET);
        att_idx++;  
    }

    srv_db_list.srv[service_hander].att_idx = att_idx;

    return cccd_idx;
}

void bk_start_service(uint8_t service_hander)
{
    struct bk_ble_db_cfg ble_db_cfg;

    if(!srv_db_list.srv[service_hander].inited)
    {
        bk_printf("service[%d] no init\r\n",service_hander);
        return;
    }

    ble_db_cfg.att_db = srv_db_list.srv[service_hander].service_db;
    ble_db_cfg.att_db_nb = srv_db_list.srv[service_hander].att_idx;
    ble_db_cfg.prf_task_id = srv_db_list.srv[service_hander].server_id;
    ble_db_cfg.start_hdl = 0;

    if(srv_db_list.srv[service_hander].uuidLen == 2)
        ble_db_cfg.svc_perm = BK_PERM_SET(SVC_UUID_LEN, UUID_16);
    else
        ble_db_cfg.svc_perm = BK_PERM_SET(SVC_UUID_LEN, UUID_128);
    memcpy(&(ble_db_cfg.uuid[0]), srv_db_list.srv[service_hander].svc_uuid, 16);

    bk_ble_create_db(&ble_db_cfg);
    rtos_delay_milliseconds(100);
}

void bk_dev_init(void)
{
    memset(&srv_db_list,0,sizeof(srv_db_list));
}

void bk_server_disconnect(void)
{
    bk_ble_disconnect(0, NULL);
}