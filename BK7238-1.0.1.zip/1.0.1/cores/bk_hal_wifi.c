#include "include.h"
#include "rtos_pub.h"
#include "wlan_ui_pub.h"
#include "bk_hal_wifi.h"
#include "vif_mgmt.h"
#include "ieee802_11_demo.h"
#include "param_config.h"
#include "common.h"
#include "rw_msg_rx.h"
#include "lwip/netif.h"

extern uint8_t bk_wlan_sta_get_channel(void);
extern sta_param_t *g_sta_param_ptr;

static bk_netif_ip_str_info_t sta_ip_config;
static bk_netif_ip_str_info_t ap_ip_config;

bk_err_t bk_wifi_start(void)
{
    return BK_OK;
}

bk_err_t bk_wifi_connect(const char * ssid, const char *pwd)
{
	network_InitTypeDef_st wNetConfig;
	int ssid_len, key_len;
	os_memset(&wNetConfig, 0x0, sizeof(network_InitTypeDef_st));

	ssid_len = os_strlen(ssid);
	key_len = os_strlen(pwd);
	if (SSID_MAX_LEN < ssid_len)
	{
		bk_printf("ssid name more than 32 Bytes\r\n");
		return BK_FAIL;
	}

	if (STA_KEY_MAX_LEN < key_len)
	{
		bk_printf("key more than buffer Bytes(107)\r\n");
		return BK_FAIL;
	}

	os_strlcpy((char *)wNetConfig.wifi_ssid, ssid, sizeof(wNetConfig.wifi_ssid));
	os_strlcpy((char *)wNetConfig.wifi_key, pwd, sizeof(wNetConfig.wifi_key));

	wNetConfig.wifi_mode = BK_STATION;


    if(!sta_ip_config.ip[0])
    {
        wNetConfig.dhcp_mode = DHCP_CLIENT;
    }
    else
    {
        wNetConfig.dhcp_mode = DHCP_DISABLE;
    }

	wNetConfig.wifi_retry_interval = 100;

    os_strcpy((char *)wNetConfig.local_ip_addr, sta_ip_config.ip);
    os_strcpy((char *)wNetConfig.net_mask, sta_ip_config.netmask);
    os_strcpy((char *)wNetConfig.gateway_ip_addr, sta_ip_config.gw);
    os_strcpy((char *)wNetConfig.dns_server_ip_addr, sta_ip_config.dns1);

    bk_printf("%s ip:%s,Gateway: %s,Netmask: %s,dns:%s\r\n", __func__,sta_ip_config.ip,sta_ip_config.gw,
                                                                     sta_ip_config.netmask, sta_ip_config.dns1);

    bk_printf("%s ip:%s,Gateway: %s,Netmask: %s,dns:%s\r\n", __func__,wNetConfig.local_ip_addr,wNetConfig.gateway_ip_addr,
                                                                     wNetConfig.net_mask, wNetConfig.dns_server_ip_addr);


	bk_printf("ssid:%s key:%s\r\n", wNetConfig.wifi_ssid, wNetConfig.wifi_key);

	bk_wlan_start(&wNetConfig);

    return BK_OK;
}

bk_err_t bk_wifi_get_mode(wifi_mode_t* mode)
{
    *mode = WIFI_MODE_NULL;

    if(bk_wlan_has_role(VIF_STA))
    {
        *mode = WIFI_MODE_STA;
    }

    if(bk_wlan_has_role(VIF_AP))
    {
        if(*mode == WIFI_MODE_NULL)
            *mode = WIFI_MODE_AP;
        else
            *mode = WIFI_MODE_APSTA;
    }

    return BK_OK;
}

bk_err_t bk_wifi_set_mode(wifi_mode_t mode)
{
    return BK_OK;
}

uint8_t bk_wifi_get_channel(void)
{
    if(bk_wlan_sta_is_connected()>0)
    {
        return bk_wlan_sta_get_channel();
    }

    if(bk_wlan_ap_is_up()>0)
    {
        return bk_wlan_ap_get_channel_config();
    }

    return 0;
}


bk_err_t bk_wifi_disconnect(void)
{
    wlan_sta_disconnect();
    return BK_OK;
}

bk_err_t bk_wifi_deinit(void)
{
    return BK_OK;
}

bk_err_t bk_wifi_stop(void)
{
    bk_wlan_stop(BK_STATION);
    bk_wlan_stop(BK_SOFT_AP);
    return BK_OK;
}

bk_err_t bk_wifi_set_ps(bool enable)
{
    if(enable)
        bk_wlan_dtim_rf_ps_mode_enable();
    else
        bk_wlan_dtim_rf_ps_mode_disable();
        
    return BK_OK;
}

bk_err_t bk_netif_set_ip_info(wifi_mode_t mode, bk_netif_ip_str_info_t *ip_info)
{
    bk_netif_ip_str_info_t *info = NULL;

    if(!ip_info)
        return BK_FAIL;

    if(mode == WIFI_MODE_STA)
    {
        info = &sta_ip_config;
    }
    else
    {
        info = &ap_ip_config;
    }

    memset(info,0,sizeof(bk_netif_ip_str_info_t));

    memcpy(info,ip_info,sizeof(bk_netif_ip_str_info_t));

    bk_printf("%s ip:%s,Gateway: %s,Netmask: %s,dns:%s\r\n", __func__,info->ip,info->gw, info->netmask, info->dns1);

    return BK_OK;
}

bk_err_t bk_netif_get_ip_info(wifi_mode_t mode, bk_netif_ip_info_t *ip_info)
{
    struct wlan_ip_config addr;

    if(mode == WIFI_MODE_STA)
        net_get_if_addr(&addr, net_get_sta_handle());
    else if(mode == WIFI_MODE_AP)
        net_get_if_addr(&addr, net_get_uap_handle());
    else
        return BK_FAIL;

    ip_addr_set_ip4_u32(&ip_info->gw,addr.ipv4.gw);
    ip_addr_set_ip4_u32(&ip_info->ip, addr.ipv4.address);
    ip_addr_set_ip4_u32(&ip_info->netmask, addr.ipv4.netmask);
    ip_addr_set_ip4_u32(&ip_info->dns, addr.ipv4.dns1);

    return BK_OK;
}


bk_err_t bk_wifi_start_softap(const char * ssid, const char *pwd)
{
	network_InitTypeDef_st wNetConfig;
	int ssid_len, key_len;
	os_memset(&wNetConfig, 0x0, sizeof(network_InitTypeDef_st));

	ssid_len = os_strlen(ssid);
	key_len = os_strlen(pwd);
	if (SSID_MAX_LEN < ssid_len)
	{
		bk_printf("ssid name more than 32 Bytes\r\n");
		return BK_FAIL;
	}

	if (STA_KEY_MAX_LEN < key_len)
	{
		bk_printf("key more than buffer Bytes(107)\r\n");
		return BK_FAIL;
	}

	os_strlcpy((char *)wNetConfig.wifi_ssid, ssid, sizeof(wNetConfig.wifi_ssid));
	os_strlcpy((char *)wNetConfig.wifi_key, pwd, sizeof(wNetConfig.wifi_key));

    bk_printf("ssid:%s key:%s\r\n", wNetConfig.wifi_ssid, wNetConfig.wifi_key);

	wNetConfig.wifi_mode = BK_SOFT_AP;
    wNetConfig.dhcp_mode = DHCP_SERVER;
    wNetConfig.wifi_retry_interval = 100;

    if(ap_ip_config.ip[0])
    {
        os_strcpy((char *)wNetConfig.local_ip_addr, ap_ip_config.ip);
        os_strcpy((char *)wNetConfig.net_mask, ap_ip_config.netmask);
        os_strcpy((char *)wNetConfig.gateway_ip_addr, ap_ip_config.gw);
        os_strcpy((char *)wNetConfig.dns_server_ip_addr, ap_ip_config.gw);
    }
    else
    {
        os_strcpy((char *)wNetConfig.local_ip_addr, BK_WLAN_DEFAULT_IP);
        os_strcpy((char *)wNetConfig.net_mask, BK_WLAN_DEFAULT_MASK);
        os_strcpy((char *)wNetConfig.gateway_ip_addr, BK_WLAN_DEFAULT_GW);
        os_strcpy((char *)wNetConfig.dns_server_ip_addr, BK_WLAN_DEFAULT_GW);
    }


    bk_printf("%s ip:%s,Gateway: %s,Netmask: %s,dns:%s\r\n", __func__,wNetConfig.local_ip_addr,wNetConfig.gateway_ip_addr,
                                                                     wNetConfig.net_mask, wNetConfig.dns_server_ip_addr);

	bk_wlan_start(&wNetConfig);

    return BK_OK;
}

bk_err_t bk_wifi_sta_get_ap_info(wifi_ap_record_t *ap_info)
{
    LinkStatusTypeDef link_conf;

    memset(&link_conf, 0, sizeof(link_conf));
    memset(ap_info, 0, sizeof(wifi_ap_record_t));
	
    if(bk_wlan_get_link_status(&link_conf)!=kNoErr)
    {
        return BK_FAIL;
    }

    memcpy(ap_info->ssid,link_conf.ssid,strlen((char*)link_conf.ssid));
    memcpy(ap_info->bssid,link_conf.bssid,sizeof(link_conf.bssid));

    ap_info->channel = link_conf.channel;
    ap_info->rssi = link_conf.wifi_strength;
    ap_info->authmode = (wifi_auth_mode_t)link_conf.security;

    memcpy(ap_info->password, g_sta_param_ptr->key,sizeof(ap_info->password));

    bk_wlan_get_country(&ap_info->country);
    
    return BK_OK;
}

bk_err_t bk_wifi_get_ap_param(wifi_ap_config_t *ap_info)
{
    network_InitTypeDef_ap_st ap_param;

	os_memset(&ap_param, 0x0, sizeof(network_InitTypeDef_ap_st));
	bk_wlan_ap_para_info_get(&ap_param);


    memcpy(ap_info->ssid,ap_param.wifi_ssid,strlen((char*)ap_param.wifi_ssid));
    memcpy(ap_info->password,ap_param.wifi_key,sizeof(ap_param.wifi_key));


    ap_info->channel = ap_param.channel;
    ap_info->ssid_hidden = ap_param.ssid_hidden;
    ap_info->max_connection = ap_param.max_con;
    ap_info->ssid_len = strlen((char*)ap_param.wifi_ssid);
    ap_info->authmode = (wifi_auth_mode_t)ap_param.security;

    return BK_OK;
}


bk_err_t bk_wifi_ap_get_sta_list(wlan_ap_stas_t *ap_info)
{
	memset(ap_info,0,sizeof(wlan_ap_stas_t));

    wlan_ap_sta_info(ap_info);
    return BK_OK;
}

bk_err_t bk_wifi_ap_netif_set_hostname(char *hostname)
{
    static char net_hostname[32] = {0};
    memset(net_hostname,0,sizeof(net_hostname));
    strcpy(net_hostname,hostname);

    netif_set_hostname((struct netif *)net_get_uap_handle(),net_hostname);

    return BK_OK;
}

char* bk_wifi_ap_netif_get_hostname(void)
{
   return (char *)netif_get_hostname((struct netif *)net_get_uap_handle());
}

bk_err_t bk_wifi_sta_netif_set_hostname(char *hostname)
{
    static char net_hostname[32] = {0};
    memset(net_hostname,0,sizeof(net_hostname));
    strcpy(net_hostname,hostname);

    netif_set_hostname((struct netif *)net_get_sta_handle(),net_hostname);

    return BK_OK;
}

char* bk_wifi_sta_netif_get_hostname(void)
{
   return (char *)netif_get_hostname((struct netif *)net_get_sta_handle());
}


static ScanResult_adv apList;
extern int hostapd_scan_started;
static const char *crypto_str[] = {
	"None",
	"WEP",
	"WPA_TKIP",
	"WPA_AES",
	"WPA_MIXED",
	"WPA2_TKIP",
	"WPA2_AES",
	"WPA2_MIXED",		////BK_SECURITY_TYPE_WPA3_SAE
	"WPA3_SAE", 		/**< WPA3 SAE */
	"WPA3_WPA2_MIXED",	/** WPA3 SAE or WPA2 AES */
	"EAP",
	"OWE",
	"AUTO",
};

static void wifi_scan_cb(void *ctxt, uint8_t param)
{
    FUNC_1PARAM_PTR fn = bk_wlan_get_status_cb();
	int ret;
    uint32_t cmd;

    if(apList.ApList)
    {
        free(apList.ApList);
        apList.ApList = NULL;
    }

	if (bk_wlan_ap_is_up() > 0 || hostapd_scan_started)
		ret = wlan_ap_scan_result(&apList);
	else
		ret = wlan_sta_scan_result(&apList);

	if (!ret) {
		int ap_num = apList.ApNum;
		int i;

		bk_printf("Got ap count: %d\r\n", apList.ApNum);
		for (i = 0; i < ap_num; i++)
			bk_printf("    \"%s\", %02x:%02x:%02x:%02x:%02x:%02x, %d, %s, %d\n",
					apList.ApList[i].ssid, MAC2STR(apList.ApList[i].bssid),
					apList.ApList[i].ApPower, crypto_str[apList.ApList[i].security],
					apList.ApList[i].channel);
	}

	if (fn) {
		cmd = RW_EVT_SCAN_DONE;
		(*fn)(&cmd);
	}
    
}


bk_err_t bk_wifi_scan_start(void)
{
    mhdr_scanu_reg_cb(wifi_scan_cb, 0);
	bk_wlan_start_scan();
    return BK_OK;    
}


bk_err_t bk_wifi_scan_get_ap_num(uint16_t *number)
{
    *number = apList.ApNum;
    return BK_OK;
}


bk_err_t bk_wifi_scan_get_ap_records(uint16_t *number, wifi_ap_record_t *ap_records)
{
    memset(ap_records,0,sizeof(wifi_ap_record_t)*(*number ));

    for(int i=0;i<*number;i++)
    {
        memcpy(ap_records[i].ssid,apList.ApList[i].ssid,strlen(apList.ApList[i].ssid));
        memcpy(ap_records[i].bssid,apList.ApList[i].bssid,sizeof(apList.ApList[i].bssid));
        ap_records[i].channel = apList.ApList[i].channel;
        ap_records[i].rssi = apList.ApList[i].ApPower;



        ap_records[i].authmode = apList.ApList[i].security; 
    }
    return BK_OK; 
}