#include "include.h"
#include "rtos_pub.h"
#include "BkDriverUart.h"
#include "drv_model_pub.h"
#include "common/error.h"
#include "bk_hal_uart.h"

OSStatus bk_uart_set_baud(uint8_t uart, int baud)
{
    UINT32 ret;
    UINT32 status;
    DD_HANDLE uart_hdl;

    if(BK_UART_1 == uart)
        uart_hdl = ddev_open(UART1_DEV_NAME, &status, 0);
    else
        uart_hdl = ddev_open(UART2_DEV_NAME, &status, 0);

    ASSERT(DRV_FAILURE != uart_hdl);

    ret = ddev_control(uart_hdl, CMD_SET_BAUT, &baud);
    ASSERT(UART_SUCCESS == ret);

    return kNoErr;
}
